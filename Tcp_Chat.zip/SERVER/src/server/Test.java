package server;

public class Test {

	public static void main(String[] args) {
		Jdbc db =new Jdbc();
		db.select("ddd", "231231");

	}

}
